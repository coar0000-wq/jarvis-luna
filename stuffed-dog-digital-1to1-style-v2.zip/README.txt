Stuffed Dog Digital — high-fidelity static recreation

This version was rebuilt from the publicly visible homepage/work/capabilities/contact structure.
It is a clean-room implementation, not a copy of the site's private WordPress/PHP source.

Included:
- responsive desktop/tablet/mobile layout
- fixed glass header + mobile menu
- hero dog composition
- scroll reveal animations
- floating/parallax dog interaction
- marquee strip
- portfolio cards
- 7 capability rows
- CTA section
- contact form with mailto fallback
- custom cursor on desktop
- reduced-motion support

Run:
python -m http.server 8000
Then open http://localhost:8000
