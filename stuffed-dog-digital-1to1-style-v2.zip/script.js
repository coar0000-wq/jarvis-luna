const header = document.getElementById("header");
const nav = document.getElementById("nav");
const burger = document.querySelector(".hamburger");

window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 30);
}, {passive:true});

burger?.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  burger.setAttribute("aria-expanded", open);
  document.body.classList.toggle("menu-open", open);
});

document.querySelectorAll(".nav a").forEach(a => {
  a.addEventListener("click", () => {
    nav.classList.remove("open");
    burger?.setAttribute("aria-expanded", "false");
    document.body.classList.remove("menu-open");
  });
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("in");
      revealObserver.unobserve(entry.target);
    }
  });
}, {threshold:.12});

document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

const dot = document.querySelector(".cursor-dot");
const ring = document.querySelector(".cursor-ring");
if (dot && ring && matchMedia("(pointer:fine)").matches) {
  let mx=0,my=0,rx=0,ry=0;
  window.addEventListener("mousemove", e => { mx=e.clientX; my=e.clientY; dot.style.left=mx+"px"; dot.style.top=my+"px"; });
  const follow=()=>{rx += (mx-rx)*.16; ry += (my-ry)*.16; ring.style.left=rx+"px"; ring.style.top=ry+"px"; requestAnimationFrame(follow)};
  follow();
  document.querySelectorAll("a,button,.service,.project").forEach(el=>{
    el.addEventListener("mouseenter",()=>{ring.style.width="54px";ring.style.height="54px"});
    el.addEventListener("mouseleave",()=>{ring.style.width="34px";ring.style.height="34px"});
  });
}

document.querySelectorAll(".magnetic").forEach(el => {
  el.addEventListener("mousemove", e => {
    const r=el.getBoundingClientRect();
    const x=(e.clientX-r.left-r.width/2)*.12;
    const y=(e.clientY-r.top-r.height/2)*.12;
    el.style.transform=`translate(${x}px,${y}px)`;
  });
  el.addEventListener("mouseleave",()=>el.style.transform="");
});

const visual = document.querySelector(".hero-visual");
const dog = document.querySelector(".dog");
if (visual && dog && matchMedia("(pointer:fine)").matches) {
  visual.addEventListener("mousemove", e => {
    const r=visual.getBoundingClientRect();
    const x=(e.clientX-r.left-r.width/2)/r.width;
    const y=(e.clientY-r.top-r.height/2)/r.height;
    dog.style.transform=`translate(${x*16}px,${y*12}px) rotate(${x*1.5}deg)`;
  });
  visual.addEventListener("mouseleave",()=>dog.style.transform="");
}

const form=document.getElementById("contactForm");
form?.addEventListener("submit", e=>{
  e.preventDefault();
  const data=new FormData(form);
  const subject=encodeURIComponent(`New inquiry from ${data.get("name")}`);
  const body=encodeURIComponent(
`Name: ${data.get("name")}
Phone: ${data.get("phone")}
Email: ${data.get("email")}
Company: ${data.get("company")}

Project Details:
${data.get("details")}`);
  location.href=`mailto:connect@stuffeddogdigital.com?subject=${subject}&body=${body}`;
});
